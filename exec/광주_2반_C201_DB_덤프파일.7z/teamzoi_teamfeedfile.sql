-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: 3.36.131.59    Database: teamzoi
-- ------------------------------------------------------
-- Server version	8.0.28-0ubuntu0.20.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teamfeedfile`
--

DROP TABLE IF EXISTS `teamfeedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teamfeedfile` (
  `teamfeedfile_id` bigint NOT NULL,
  `file_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `file_type` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `original_file_name` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `teamfeed_id` bigint DEFAULT NULL,
  `savefolder` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`teamfeedfile_id`),
  KEY `FK9lto2esv7r7mtnkf1no37ys93` (`teamfeed_id`),
  CONSTRAINT `FK9lto2esv7r7mtnkf1no37ys93` FOREIGN KEY (`teamfeed_id`) REFERENCES `teamfeed` (`teamfeed_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teamfeedfile`
--

LOCK TABLES `teamfeedfile` WRITE;
/*!40000 ALTER TABLE `teamfeedfile` DISABLE KEYS */;
INSERT INTO `teamfeedfile` VALUES (22,'9a746fc9-98ee-4fa7-ad0c-1dd1592f1166.png','IMAGE','커비.png',23,NULL),(24,'65d4f662-cecc-42b5-90f4-75ea5d68fdce.png','GENERAL','커비.png',23,NULL),(25,'773e3215-cf97-4e1c-b829-e73487b6e500.png','IMAGE','커비.png',26,NULL),(27,'4fae13bd-0464-4add-92fa-48065d40ed4e.xlsx','GENERAL','지원.xlsx',26,NULL),(40,'b45bb33b-a542-4667-9076-8b7ff4bec558.png','IMAGE','커비.png',41,NULL),(42,'1d5fb451-0c70-4256-9e0f-cc248a231ed8.png','GENERAL','커비.png',41,NULL),(45,'bb35337c-06cd-46aa-ba39-5d7128ee0f45.png','IMAGE','커비.png',46,NULL),(47,'35924a7f-d5c5-489b-8fea-079bbe17d17f.png','GENERAL','커비.png',46,NULL),(49,'4ab372f3-e72a-4777-9a2b-626808bb6034.jpg','IMAGE','flower.jpg',50,NULL),(51,'dd6712d7-6939-4af2-adc2-885d68b8d5b9.jpg','GENERAL','flower.jpg',50,NULL),(54,'174685a4-1677-46cc-944f-c9866d7b6773.jpg','IMAGE','flower.jpg',55,NULL),(56,'ddc4c60a-3762-48f2-b61f-79f809973afc.jpg','GENERAL','flower.jpg',55,NULL),(58,'62d84517-173e-412b-8c49-3d487f3f185b.jpg','IMAGE','flower.jpg',59,NULL),(60,'b21a7e97-3f3c-4848-86b3-6b6a791b2e45.jpg','GENERAL','flower.jpg',59,NULL),(63,'e57185d0-3ad0-4fc7-bd5e-128a83768568.jpg','IMAGE','flower.jpg',64,NULL),(65,'ebcb6a82-5400-4555-a4f0-246b3cb6f0e4.jpg','GENERAL','flower.jpg',64,NULL),(68,'660c97dd-9e51-48b5-a94a-d2a8bbe869b9.jpg','IMAGE','flower.jpg',69,NULL),(70,'4d775d86-0f02-44e2-ba5c-ff7573815683.jpg','GENERAL','flower.jpg',69,NULL),(76,'4fb2693b-fe76-4e43-a20a-ab71308dd500.png','IMAGE','커비.png',77,NULL),(78,'2e79347d-417d-4a31-83a5-2928b9ed1adf.png','GENERAL','커비.png',77,NULL),(79,'bd3828fa-11a1-4ff8-8663-7bfd375dce6e.png','IMAGE','커비.png',80,NULL),(81,'e613c6b1-6dcb-4ae8-9aa6-fb777535c236.png','GENERAL','커비.png',80,NULL),(82,'5f3f495b-42c0-40f7-85e0-a1f1850da8a7.png','IMAGE','커비.png',9,NULL),(83,'35f8e7a9-c93f-4105-aecc-f33faab5ff3d.png','GENERAL','커비.png',9,NULL),(106,'00196424-0951-495d-9c5a-9dc417fd9f87.png','IMAGE','커비.png',107,NULL),(108,'c86159e5-0946-4c03-bc63-c1323263093b.png','GENERAL','커비.png',107,NULL),(109,'3ed934ae-73f1-4f20-95a5-e308a0dcb7e7.png','IMAGE','커비.png',110,NULL),(111,'d4244f39-8f2b-4f49-9f11-28e38d11376f.png','GENERAL','커비.png',110,NULL),(112,'c8a3118b-1c15-41f3-8354-b9c52444df6f.png','IMAGE','커비.png',113,NULL),(114,'123ccad9-76b9-4ded-9f33-b0842acc691d.png','GENERAL','커비.png',113,NULL),(118,'05e10f14-5a2a-4bea-97c0-b9b442925ac0.png','IMAGE','커비.png',107,NULL),(119,'4e1d8cdc-cb5d-4819-821c-5da43e8bba6a.png','GENERAL','커비.png',107,NULL),(121,'d3ddbf3a-997b-4c4a-9e4c-19917a1240bb.png','IMAGE','커비.png',122,NULL),(123,'098bff97-3c41-4bb0-97ce-1cef71d13591.png','GENERAL','커비.png',122,NULL),(127,'0426d1ab-d20a-435d-ac5a-f89841568cfa.png','IMAGE','커비.png',128,NULL),(129,'928c613c-4419-42d2-bd8b-84ab21467a85.png','GENERAL','커비.png',128,NULL),(130,'a2316913-be56-47ea-a862-39107c242530.png','IMAGE','커비.png',122,NULL),(131,'b1906741-10d9-4fad-8092-65ee3957c891.png','GENERAL','커비.png',122,NULL),(142,'c6cb195a-580e-443b-8bf7-53a317a28d2e.png','IMAGE','커비.png',143,NULL),(144,'7c83449a-05b9-4cef-8b30-5c6fa5d8f2cc.xlsx','GENERAL','지원.xlsx',143,NULL),(145,'1ad5697b-10dd-4fe3-a3bc-206de383f534.png','IMAGE','커비.png',146,NULL),(148,'7e4fe2c8-abc3-4d29-98b2-9b97e92778b4.exe','IMAGE','Postman.exe',149,NULL),(152,'92ccf6c1-0bf0-42b2-97d1-8ae0d2193c22.png','IMAGE','커비.png',153,NULL);
/*!40000 ALTER TABLE `teamfeedfile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-02-17 20:51:26
